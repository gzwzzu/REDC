
**____________________________________________________________________________**________

use C:\Users\巧米米\Desktop\三峡库区\psm-did\psm-did.dta

gen did_sg=did*shui_g

global xlist "lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t "
sum score $xlist  //统计描述相关变量

**————————————————————————————————————————————————————————————————————————————————————
**DID方法-----------------------------------
gen time = (year >= 2014) & !missing(year)  //政策执行时间为1977年
xtreg score did time treated $xlist i.year, fe 
**————————————————————————————————————————————————————————————————————————————————————————
**PSM-DID方法-------------------------------
 
 sysdir set  PLUS  "D:\stata17\ado\plus\p"
search psmatch2


** PSM的部分
set seed 0001	//定义种子
gen tmp = runiform() //生成随机数
sort tmp //把数据库随机整理



** DID的部分，根据上面匹配好的数据
***KErnel核匹配后回归结果
psmatch2 treated $xlist, out(score) logit ate kernel common caliper(.05) ties
pstest $xlist, both graph  //检验协变量在处理组与控制组之间是否平衡
gen common1=_support
drop if common1 == 0  //去掉不满足共同区域假定的观测值
psgraph
xtreg score did time treated $xlist i.year, fe 
est sto Y1

***半径卡尺匹配后回归结果
psmatch2 treated $xlist, out(score) logit ate radius common caliper(.05) ties //通过近邻匹配，这里可以要outcome，也可以不要它
pstest $xlist, both graph  //检验协变量在处理组与控制组之间是否平衡
gen common2=_support
drop if common2== 0  //去掉不满足共同区域假定的观测值
psgraph
xtreg score did time treated $xlist i.year, fe 
est sto Y2

**近邻匹配后回归结果
psmatch2 treated $xlist, out(score) logit ate neighbor(4) common caliper(.05) ties //通过近邻匹配，这里可以要outcome，也可以不要它
pstest $xlist, both graph  //检验协变量在处理组与控制组之间是否平衡
gen common3=_support
drop if common3 == 0  //去掉不满足共同区域假定的观测值
psgraph
xtreg score did time treated $xlist i.year, fe 
est sto Y3

 sysdir set  PLUS  "D:\stata17\ado\plus\o"
ssc install outreg2
 sysdir set  PLUS  "D:\stata17\ado\plus\e"
ssc install esttab
esttab Y3 ,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)
outreg2 [Y1 Y2 Y3] using "表稳健性检验-PSM-DID（kernrel radius neighbor）.doc",replace addtext(yearfix,YES,idfix,YES) tstat bdec(3) tdec(3) rdec(3) 