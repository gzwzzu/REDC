*---------------------------------------------------------
*第一部分，如何构建交互项（需要使用案例数据包括：“数据.dta”和“基础信息.dta”
*---------------------------------------------------------
*方法1：构建基础数据进行匹配
gen t=0  //构建变量t
replace t=1 if year>=treat_year  //构建政策变量，政策后赋值为1，政策前赋值为0
replace t=0 if treat_year==0
gen did=treated*t  //创建交互项

gen id=group(dum)
 sysdir set  PLUS  "D:\stata18\ado\plus\r"
ssc install reghdfe
 sysdir set  PLUS  "D:\stata17\ado\plus\o"
ssc install outreg2


gen lnc1=log(c1)
gen lnc2=log(c2)
gen lnc3=log(c3)
gen lnc4=log(c4)
gen lnc5=log(c5)
gen lngovern=log(govern)
gen lncitydi=log(citydi)
gen lnruraldi=log(ruraldi)
gen s_t=log(scdind+thrind)
gen lnsci=lnc1
gen lnlabor_rate=lnc2
gen ur_rate=lnc3
gen structure=lnc4
gen ind_addvance=lnc5
gen did_sg=shui_g*did
*---------------------------------------------------------
*第二部分，基准回归，介绍了高维回归和普通面板回归
*---------------------------------------------------------
*1、固定效应（聚类）

**政策对共同富裕指数--正效应
*高维回归：
reghdfe score did, absorb(id year) vce(robust)
est store A1
reghdfe score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year)  vce(robust)
est store A2
*面板回归：
xtset id year
xtreg score did i.year,fe  vce(robust)
est store A3
xtreg score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg  lnfdi finace nfp s_t i.year,fe vce(robust)
est store A4

**政策对发展性指数--正效应
*高维回归：
reghdfe develop did, absorb(id year)  vce(robust)
est store C1
reghdfe develop did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t, absorb(id year)  vce(robust)
est store C2

**政策对共享性指数--不显著
*高维回归：
reghdfe share did, absorb(id year)  vce(robust)
est store C3
reghdfe share did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi  finace nfp s_t, absorb(id year)  vce(robust)
est store C4


 sysdir set  PLUS  "D:\stata17\ado\plus\e"
search esttab
sysdir set  PLUS  "D:\stata17\ado\plus\o"
ssc install outreg2

esttab A1 A2  A3 A4 ,    ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)


esttab C1 C2  C3 C4  ,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)


outreg2 [A1 A2  A3 A4] using "表1基准回归1.doc",replace addtext(yearfix,YES,idfix,YES) tstat bdec(3) tdec(3) rdec(3) 
outreg2 [C1 C2  C3 C4] using "表2基准回归2.doc",replace addtext(yearfix,YES,idfix,YES)  tstat  bdec(3) tdec(2) rdec(3) 

*---------------------------------------------------------
*第三部分，平行趋势检验

*---------------------------------------------------------
*step1：构建虚拟变量

gen u=0 
replace u=1 if treat_year>0

gen xianhou=treat_year - year if u>0
tab xianhou

replace xianhou = -5 if xianhou <= -5
replace xianhou = 6 if xianhou >= 6 
replace xianhou =. if u==0
tab xianhou , gen(xh)

forvalues i = 1/12{
replace xh`i' = 0 if xh`i' == .
}
drop xh1


*step2：作图
sysdir set  PLUS  "D:\stata17\ado\plus\c"
ssc install coefplot,replace

reghdfe score did  xh2  xh4 xh5 xh6 xh7 xh8 xh9 xh10 xh11 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t, absorb(id year) vce (robust)
est store D1
coefplot, baselevels keep( xh2 xh4 xh5 xh6 xh7 xh8 xh9 xh10 xh11) vertical yline(0) ytitle("政策效应") xtitle("政策前后") addplot(line @b @at) ciopts(recast(rcap)) scheme(s1mono) levels(90)  coeflabels( xh2 = "-3" xh4 = "-2" xh5="-1"  xh6 = "0" xh7  = "1" xh8  = "2" xh9  = "3" xh10  = "4" xh11="5") xline(4,lp(shortdash))

reghdfe develop did  xh2 xh3 xh4 xh5 xh6 xh7 xh8 xh9  lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg  lnfdi finace nfp s_t , absorb(id year) vce (robust)
est store D2
coefplot, baselevels keep( xh2 xh3 xh4 xh5 xh6 xh7 xh8 xh9 ) vertical yline(0) ytitle("政策效应") xtitle("政策前后") addplot(line @b @at) ciopts(recast(rcap)) scheme(s1mono) levels(90)  coeflabels( xh2="-4" xh3="-3" xh4 = "-2" xh5="-1"  xh6 = "0" xh7  = "1" xh8  = "2" xh9  = "3" ) xline(5,lp(shortdash))

reghdfe share did xh2 xh3 xh4 xh5 xh6 xh7 xh8 xh9 xh10 xh11 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t, absorb(id year) vce (robust)
est store D3
coefplot, baselevels keep( xh2 xh3 xh4 xh5 xh6 xh7 xh8 xh9 xh10 xh11 ) vertical yline(0) ytitle("政策效应") xtitle("政策前后") addplot(line @b @at) ciopts(recast(rcap)) scheme(s1mono) levels(95)  coeflabels( xh2 = "-4" xh3="-3" xh4 = "-2" xh5="-1"  xh6 = "0" xh7  = "1" xh8  = "2" xh9  = "3" xh10  = "4" xh11= "5") xline(5,lp(shortdash))

esttab D1 D2   ,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)
outreg2 [D1 D2] using "表3平行趋势.doc",replace addtext(yearfix,YES,idfix,YES)  tstat bdec(3) tdec(3) rdec(3) 


*--------------------------------------------------------
*---------------------------------------------------------
*第四部分，反事实检验（安慰剂检验）
*---------------------------------------------------------
 sysdir set  PLUS  "D:\stata17\ado\plus\r"
search reghdfe

*第一种：时间安慰剂检验（改变政策时间，例如提前实施政策）
clear 
***分别提前1-5期，均不显著
gen ac_1=treat_year-1
gen t_1=0
replace t_1=1 if year> ac_1
gen treated_1=ac_1 
replace treated_1=0 if ac_1>2014
replace treated_1=1 if ac_1<2014
gen did_1=treated_1*t_1
reghdfe score did_1 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year) vce(robust) 
est store Z1

gen ac_2=treat_year-2
gen t_2=0
replace t_2=1 if year> ac_2
gen treated_2=ac_2 
replace treated_2=0 if ac_2>2013
replace treated_2=1 if ac_2<2013
gen did_2=treated_2*t_2
reghdfe score did_2 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi  finace nfp s_t , absorb(id year) vce(robust) 
est store Z2

gen ac_3=treat_year-3
gen t_3=0
replace t_3=1 if year> ac_3
gen treated_3=ac_3 
replace treated_3=0 if ac_3>2012
replace treated_3=1 if ac_3<2012
gen did_3=treated_3*t_3
reghdfe score did_3 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year) vce(robust) 
est store Z3

gen ac_4=treat_year-4
gen t_4=0
replace t_4=1 if year> ac_4
gen treated_4=ac_4 
replace treated_4=0 if ac_4>2011
replace treated_4=1 if ac_4<2011
gen did_4=treated_4*t_4
reghdfe score did_4 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year) vce(robust) 
est store Z4

gen ac_5=treat_year-5
gen t_5=0
replace t_5=1 if year> ac_5
gen treated_5=ac_5 
replace treated_5=0 if ac_5>2010
replace treated_5=1 if ac_5<2010
gen did_5=treated_5*t_5
reghdfe score did_5 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year) vce(robust) 
est store Z5

esttab Z1 Z2 Z3 Z4 Z5  ,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)
outreg2 [Z1 Z2 Z3 Z4 Z5] using "表8时间安慰剂检验.doc",replace addtext(yearfix,YES,idfix,YES)  tstat bdec(3) tdec(3) rdec(3) 

***个体安慰剂检验
clear
mat b = J(2000,1,0)
mat se = J(2000,1,0)
mat p = J(2000,1,0)

forvalues i = 1/2000{ 
  use new多期did.dta, clear
  xtset id year
  keep if year==2015
  sample 9,count   
  keep id
  save matchid.dta,replace
  merge 1:m id using new多期did.dta
  gen treat=(_merge ==3)  
  save matchid`i'.dta,replace

  use new多期did.dta  
  bsample 1, strata(id) 
  keep year
  save matchyear.dta, replace
  mkmat year, matrix(sampleyear)

  use matchid`i'.dta,replace
  xtset id  year
  gen time = 0
  foreach j of numlist 1/285 {  
  replace time = 1 if (id == `j'&year >= sampleyear[`j',1]) 
  }
   gen did1=time*treat
   qui reghdfe score did1 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year) vce(robust) 
   mat b[`i',1] = _b[did1]
   mat se[`i',1] = _se[did1]
   scalar df_r = e(N) - e(df_m) -1
   mat p[`i',1] = 2*ttail(df_r,abs(_b[did1]/_se[did1]))
}

svmat b, names(coef)
svmat se, names(se)
svmat p, names(pvalue)
drop if pvalue1 == .
label var pvalue1 p_value
label var coef1 estimate
twoway(scatter pvalue1 coef1 , xlabel(-0.02(0.01)0.02, grid)  yline(0,lp(dash))   xline(0.0143,lp(dash)) xtitle(estimate)  msymbol(smcircle_hollow) mcolor(red) legend(off)) (kdensity coef1, yaxis(2)  legend(off) title("Placebo test")), ytitle("p_value",axis(1)) ytitle("kdensity",axis(2)) xlabel(0.0143,add labsize(*.75))  ylabel(0.008,add labsize(*.75)) 

**t值图
clear
use new多期did.dta,clear
forvalue i=1/2000{
use "new多期did.dta"
 g obs_id= _n
 gen random_digit= runiform()
 sort random_digit
 g random_id= _n
 preserve
 keep random_id did
 rename did random_did/**/
 rename random_id id1
 label var id1
 save random_did, replace
 restore
 drop random_digit random_id did
 rename obs_id id1
 label var id1
 save rawdata, replace
 use rawdata, clear
 merge 1:1 id1 using random_did,nogen/****/
 xtset id year
 global control "lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t"
 xtreg score  random_did $control i.year,fe
 g _b_random_did= _b[random_did] 
 g _se_random_did= _se[random_did] 
 keep _b_random_did _se_random_did 
 duplicates drop _b_random_did, force
 save placebo`i', replace 
}
 use placebo1, clear
forvalue i=2/2000{
 append using placebo`i' 
} 

gen tvalue= _b_random_did/ _se_random_did

kdensity tvalue,xtitle("t_value")  ytitle("distribution") title("Placebo test") tline(2.646,lp(dash) lc(black) ) tlabel(0,add labsize(*.75)) xlabel(-7(2)7) tlabel(2.646,add labsize(*.75)) 

---------------------------------------------------------
*稳健性检验
*---------------------------------------------------------
sysdir set  PLUS  "D:\stata17\ado\plus\r"
search reghdfe
 sysdir set  PLUS  "D:\stata17\ado\plus\o"
ssc install outreg2
*1、控制非平行趋势
*时间趋势项的控制方法：
*(1)加trend
reghdfe score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t  trend, absorb(id) vce (robust)
est sto E5
outreg2 [E5] using "表稳健性-trend.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3)
*（2）在回归中加入c.是否主城核心区#c.year
clear
gen Q=0
replace Q=1 if id==8
replace Q=1 if id==9
replace Q=1 if id==10
replace Q=1 if id==11
replace Q=1 if id==12
replace Q=1 if id==14
replace Q=1 if id==15
gen trend=year-treat_year 
reghdfe score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t  c.Q#c.trend, absorb(year id) vce (robust)
est sto E1
sysdir set  PLUS  "D:\stata17\ado\plus\o"
ssc install outreg2
outreg2 [E1 ] using "表稳健性-C.Q#c.trend.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3)
*2、对核心变量缩尾处理
sysdir set  PLUS  "D:\stata17\ado\plus\w"
search winsor2

winsor2 score ,replace cuts(1 99)
reghdfe score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year) vce (cluster id)
est sto E2
esttab  E2 E3,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)
winsor2 score,replace cuts(5 95)
reghdfe score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t  , absorb(id year) vce (cluster id)
est sto E3
outreg2 [E2 E3] using "表稳健性-样本值筛选.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3)

*3、换方法-ols**
reg score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t  i.id i.year,cluster(id)
est sto E4
outreg2 [E4] using "表稳健性-ols.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3)
clear
*4、换方法-csdid***
des
sysdir set  PLUS  "D:\stata17\ado\plus\c"
ssc install csdid
gen first_treat=treat_year
replace first_treat=0 if first_treat==.
csdid score did , ivar(id) time(year) gvar(first_treat) method(drimp) agg(simple) vce(cluster )
est sto E5
csdid score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t, ivar(id) time(year) gvar(first_treat) method(drimp) agg(simple) vce(cluster)
est sto E6
outreg2 [E5 E6] using "表稳健性-csdid.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3)


*6、剔除异常值（去掉主城核心区）
drop if id==8
drop if id==9
drop if id==10
drop if id==11
drop if id==12
drop if id==14
drop if id==15
reghdfe score did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi, absorb(id year) vce (robust)
est sto E8

**结果储存
esttab E8,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)


sysdir set  PLUS  "D:\stata17\ado\plus\o"
ssc install outreg2
outreg2 [E8] using "表稳健性-主城核心区剔除.doc",replace addtext(yearfix,YES,idfix,YES) tstat bdec(3) tdec(3) rdec(3) 
outreg2 [E5 E6] using "表稳健性2-CSDID.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3) 

**第六部分、机制检验
***一次分配-做大蛋糕（效率）
***1、产出效应（人均gdp）
reghdfe lnp_gdp did lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t , absorb(id year) vce(robust)
est store  F1

gen M1=lnp_gdp*did

reghdfe score M1  lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg  lnfdi finace nfp s_t , absorb(id year) vce(robust)
est store F2
***2、产业集聚效应（区位熵）
gen lnlq=log(lq)
gen localq=lnlq
reghdfe localq did lnsci lnlabor_rate  ur_rate structure ind_addvance did_lng lnfdi finace nfp s_t ,  absorb(id year) vce(robust)
est store F3
gen M2=localq*did
reghdfe score M2 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi  finace nfp s_t, absorb(id year) vce(robust)
est store F4
sysdir set  PLUS  "D:\stata17\ado\plus\s"
 install segmidiation2

**二次分配，注重公平
***5、公共财政支出规模（一般预算支出/地区GDP）
reghdfe governcost did  lnsci lnlabor_rate  ur_rate structure ind_addvance did_lng lnfdi finace nfp s_t, absorb(id year) vce(robust)
est store G1
gen M3=governcost*did
reghdfe score  M3 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg  lnfdi finace nfp s_t , absorb(id year) vce(cluster id)
est store G2


**提低效应（农村居民收入）
reghdfe lnruraldi did  lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg  lnfdi , absorb(id year) vce(robust)
est store G3
gen M5=lnruraldi*did
reghdfe score  M5 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t  , absorb(id year) vce(robust)
est store G4
***4、缩小城乡收入差距（反向）文中用Gap表示了diff)
reghdfe diff did  lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi , absorb(id year) vce(robust)
est store G5
gen M4=diff*did
reghdfe score M4  diff  lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t, absorb(id year) vce(robust)
est store G7

***三次分配--增加社会（公益事业规模）
reghdfe welfare did  lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace nfp s_t, absorb(id year) vce(robust)
est store H1
gen M6= welfare*did
reghdfe score M6 lnsci lnlabor_rate  ur_rate structure ind_addvance did_sg lnfdi finace , absorb(id year) vce(robust)
est store H2

**结果储存
esttab F1 F2  F3 F4  ,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)
esttab G1 G2  G3 G4 G5 G6 ,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)
esttab H1 H2,  ///
star(* 0.1 ** 0.05 *** 0.01) b(%6.3f) sca(F r2)

sysdir set  PLUS  "D:\stata17\ado\plus\o"
ssc install outreg2
outreg2 [F1 F2  F3 F4] using "表1机制检验一次分配.doc",replace addtext(yearfix,YES,idfix,YES) tstat bdec(3) tdec(3) rdec(3) 
outreg2 [G1 G2  G3 G4 G5 G6] using "表2机制检验二次分配.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3) 
outreg2 [H1 H2] using "表3机制检验三次分配.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3) 
outreg2 [G7] using "表2机制检验二次分配GAP.doc",replace addtext(yearfix,YES,idfix,YES) tstat  bdec(3) tdec(3) rdec(3) 