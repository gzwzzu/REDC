*---------------------------------------------------------
*第一部分，如何构建交互项（需要使用案例数据包括：“数据.dta”和“基础信息.dta”
*---------------------------------------------------------
*方法1：构建基础数据进行匹配
cd C:\Users\31808\Desktop\多期DID  //设定默认工作路径，若不会可见B站视频：https://www.bilibili.com/video/BV1sY411P7vL/?vd_source=a5dbe92e7226dd67f136d618c5bbee15
use "C:\Users\31808\Desktop\多期DID\数据.dta"  //打开数据
joinby id using 基础信息.dta //匹配数据，一对多匹配的方法，如果不明白可见B站视频：https://www.bilibili.com/video/BV1pg411N7Se/?spm_id_from=333.788.recommend_more_video.1&vd_source=a5dbe92e7226dd67f136d618c5bbee15
gen t=0  //构建变量t
replace t=1 if year>=time  //构建政策变量，政策后赋值为1，政策前赋值为0
gen did=treated*t  //创建交互项

*方法2：赋值（直接构建交互项）
clear
use "C:\Users\31808\Desktop\多期DID\数据.dta"
gen td=0
replace td=1 if (city=="A"|id=="E") &(year >= 2018) // "|"的意思是或，"&"的意思是且
replace td=1 if (city=="C") &(year >= 2020)  

*方法3：赋值（只构建政策时间项）
clear
use "C:\Users\31808\Desktop\多期DID\数据.dta"
joinby id using 基础信息.dta
gen t=0
replace t=1 if year>=time
  
  
  
*-------------------------------以下内容需要使用的是“date.dta”数据----------------------------- ---- 
  
  
*---------------------------------------------------------
*第二部分，基准回归，介绍了高维回归和普通面板回归
*---------------------------------------------------------
*1、固定效应（不聚类）
高维回归：reghdfe y did x* ,absorb(id year)
面板回归：xtreg y did x*  i.year,fe
*2、固定效应（聚类）
*（1）使用高维回归如何实现操作？
reghdfe y did x* ,absorb(id year) vce(cluster id)
est store a1
*（2）xtreg如何做聚类？
xtreg y did x*  i.year,fe cluster(id)
est store a2
outreg2 [a1 a2] using "123.doc",replace addtext(yearfix,YES,idfix,YES) bdec(3) sdec(3)

*---------------------------------------------------------
*第三部分，平行趋势检验
*---------------------------------------------------------
*step1：构建虚拟变量
gen u=0
replace u=1 if action<2222
gen xianhou= year - action if u>0
tab xianhou
replace xianhou = -5 if xianhou <= -5
replace xianhou = 6 if xianhou >= 6 
replace xianhou =. if u==0
tab xianhou , gen(xh)
forvalues i = 1/12{
replace xh`i' = 0 if xh`i' == .
}
drop xh1

*step2：作图
xtreg y xh* x* i.year,fe
coefplot, baselevels keep(xh*) vertical yline(0) ytitle("政策效应") xtitle("政策前后") addplot(line @b @at) ciopts(recast(rcap)) scheme(s1mono) levels(95)    coeflabels(xh2 = "-4" xh3 = "-3" xh4 = "-2" xh5 = "-1" xh6 = "0" xh7  = "1" xh8  = "2" xh9  = "3" xh10  = "4" xh11  = "5"  xh12  = "6") xline(5,lp(shortdash))


*---------------------------------------------------------
*第四部分，反事实检验（安慰剂检验）
*---------------------------------------------------------

*第一种：时间安慰剂检验（改变政策时间，例如提前实施政策）
clear 
use date
xtset id year
gen ac_4=action-4
gen t_4=0
replace t_4=1 if year> ac_4 
gen treated_4=ac_4 
replace treated_4=0 if ac_4>2200
replace treated_4=1 if ac_4<2200
gen did_4=treated_4*t_4
xtreg y did_4 x* i.year,fe

*第二种：个体安慰剂检验（具体解析见pdf或者视频）

clear
mat b = J(500,1,0)
mat se = J(500,1,0)
mat p = J(500,1,0)

forvalues i = 1/500{ 
  use date.dta,clear  
  xtset id year
  keep if year==2015
  sample 121,count   
  keep id
  save matchid.dta,replace
  merge 1:m id using date.dta
  gen treat=(_merge ==3)  
  save matchid`i'.dta,replace

  use date.dta  
  bsample 1, strata(id) 
  keep year
  save matchyear.dta, replace
  mkmat year, matrix(sampleyear)

  use matchid`i'.dta,replace
  xtset id  year
  gen time = 0
  foreach j of numlist 1/285 {  
  replace time = 1 if (id == `j'&year >= sampleyear[`j',1]) 
  }
   gen did1=time*treat
   qui xtreg y did1   x*  i.year,fe 
   mat b[`i',1] = _b[did1]
   mat se[`i',1] = _se[did1]
   scalar df_r = e(N) - e(df_m) -1
   mat p[`i',1] = 2*ttail(df_r,abs(_b[did1]/_se[did1]))
}


svmat b, names(coef)
svmat se, names(se)
svmat p, names(pvalue)
drop if pvalue1 == .
label var pvalue1 p值
label var coef1 估计系数
twoway(scatter pvalue1 coef1 , xlabel(-0.015(0.01)0.015, grid)  yline(0.1,lp(shortdash))   xline(0.0128,lp(shortdash)) xtitle(估计系数)  msymbol(smcircle_hollow) mcolor(red) legend(off)) (kdensity coef1, yaxis(2)  legend(off) title(安慰剂检验)), ytitle("p值",axis(1)) ytitle("核密度",axis(2))



*---------------------------------------------------------
*第五部分，稳健性检验）
*---------------------------------------------------------

*1、控制非平行趋势
*时间趋势项的控制方法：
*（1）在回归中加入c.year
*（2）gen trend=year-初始年份→在回归中控制trend
*交互项中有连续变量或者虚拟变量时，控制时间趋势的方法为：
xtreg y did x*  c.x1#c.year i.year,fe
xtreg y did x*  c.是否沿海#c.year i.year,fe
*个体固定效应和时间趋势的交互项：
xtreg y did x*  i.id#c.year  i.year,fe
*2、控制竞争性政策干扰
xtreg y did x*  did1 did2  i.year,fe


*3、对核心变量缩尾处理
winsor2 y ,replace cuts(1 99)
xtreg y did x* i.year,fe
clear
use date.dta
winsor2 y ,replace cuts(5 95)
xtreg y did x*  i.year,fe
*4、交互固定效应
xtreg y did x*  did1 did2  i.year i.year#i.id,fe  //加入了时间-个体交互固定效应






