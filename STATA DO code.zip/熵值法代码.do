*=========================== 需要设置 =========================== 
gen id=group(dum)

//正向指标
global positive_var x1 x2 x3 x4 x7 x8 x9 x10 x11 x12 x13 x14 x16 x17
//负向指标
global negative_var x5 x6 x15 x18
*================================================================ 
	

*========================= 后面无需改动 ========================= 

//所有指标
global all_var $positive_var $negative_var
//年份
qui sum year
global min_year=r(min)
global max_year=r(max)

forvalues year=$min_year / $max_year{
use "C:\Users\巧米米\Desktop\三峡库区\数据\shangquanfa\shangquanfa.dta", clear
	keep if year==`year'

	//将数据标准化处理 -正向指标
	foreach i in $positive_var {
		qui sum `i'
		gen x_`i'=(`i'-r(min))/(r(max)-r(min))
		replace x_`i'=0.00001 if x_`i'==0
	}
	
	//将数据标准化处理 -负向指标
	foreach i in $negative_var {
		qui sum `i'
		gen x_`i'=(r(max)-`i')/(r(max)-r(min))
		replace x_`i'=0.00001 if x_`i'==0
	}

	//计算指标比重
	foreach i in $all_var {
		egen `i'_sum=sum(x_`i')
		gen y_`i'=x_`i'/`i'_sum
	}

	//根据比重计算各分量的信息熵
	gen n=_N

	foreach i in $all_var {
		gen y_lny_`i'=y_`i'*ln(y_`i')
	}

	//求和
	foreach i in $all_var {
		egen y_lny_`i'_sum=sum(y_lny_`i')
	}

	//计算各指标的贡献总量
	foreach i in $all_var {
		gen E_`i'= -1/ln(n)*y_lny_`i'_sum
	}

	//计算各指标的权重
	foreach i in $all_var {
		gen d_`i'= 1-E_`i'
	}
	
	egen d_sum = rowtotal(d_*)
	foreach i in $all_var {
		gen W_`i'= d_`i'/d_sum
	}
	
	//计算最后综合得分
	foreach i in $all_var {
		gen Score_`i'= x_`i'*W_`i'
	}
	
	
	egen Score=rowtotal(Score_*)

	keep id year dum $all_var Score
	save data_`year', replace
}

clear
forvalues i= $min_year / $max_year {
   append using data_`i'
   rm data_`i'.dta
}

sort id year
save result.dta, replace

//其中数据中的Score列就是计算出来的综合指标
